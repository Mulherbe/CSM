<?php 

//  LIST
    // CHOISIR FONT  ---------------------------------------------------------> EVE
        //  Create BDD &  requête --------------------------------------------> KEVIN
        //Page login ---------------------------------------------------------> FRED (front fini need back)
        //Page interface -----------------------------------------------------> EVE
        //Page Ajout fiche ---------------------------------------------------> 
        //Page Ajout user
        //Page moderation
        //Page archive
        //Page MDP oublié
            // Interface login + Hash mdp + Secu + Cookies retenir MDP 
            // Formulaire ajout fiche
            // bouton supp(archive) /  bouton modifier (modal ?)
            // Boutton Deco --------------------------------------------------> FRED
                // Responsive
                // Refactoring
           

                                // SUPER ADMIN
                                        //  Page ajout utilisateur
                                        // Page archives
                                            // espace moderation
                                            //  Gerer les users 
                                            // Acces archives
                                            // Bouton re mettre en ligne une fiche by archives
                                         
                                //ADMIN
                                    
                                                            // MAYBE
                                                                // Ajout des fonctions diplomes et certifiction lié avec metier
                                                                // Liste formation
                                                                // Centre formation lié au titre
                                                                // Light/ Dark mode

                                                                
    

        //  DONE
                   //Create MVC