<?php 
  
    class Database{

        
        static function ID(){
            $servname = 'localhost';
            $dbname = 'impauto';
            $user = 'root';
            $dbco = new PDO("mysql:host=$servname;dbname=$dbname", $user);
            return $dbco;
        } 

    }