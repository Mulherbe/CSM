<?php
	
	class Connexion
			{

					static function login($username,$MDP){
		
           
				$con =Database::ID();
	
				$coBDD = $con->prepare("SELECT * FROM utilisateurs WHERE Mail = :mail AND Mot_De_Passe = :mdp  ");
				$coBDD ->execute(array(":mail"=>$username, ":mdp"=>$MDP));
				$coBDD   = $coBDD ->fetchAll(PDO::FETCH_ASSOC);
		
	
	
			  foreach($coBDD  as  $key => $value){
						
					if ($value['Username'] == $username && $value['pass'] == $MDP ) {
						$id = $value['ID'];
						$user = $value['Username'];
						$_SESSION['id'] = $id;
						$_SESSION['user'] = $user;
						echo "Salut".$_SESSION['user'];
						break;
	
					} 
				
			}
	
		}

	

		function session()
		{

		}

		function coockie()
		{

		}

		function recuperation_MDP()
		{

		}
		
	}