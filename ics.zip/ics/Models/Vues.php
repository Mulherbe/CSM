<?php 
  
    class Vues{

                    
                // Generate  Page  login

                function generateView_login(){

                    $template = file_get_contents("Vues/template.tpl");

                        $accueil = file_get_contents("Vues/accueil.tpl");

                        $login = file_get_contents("Vues/login.tpl");


                        $template = str_replace("<!--ContentView-->", $accueil, $template);
                        return str_replace("<!--baniere-->", $login, $template);
                }


                function generateView_fiche(){

                    $template = file_get_contents("Vues/template.tpl");

                        $fiche = file_get_contents("Vues/fiche.tpl");

                        $baniere = file_get_contents("Vues/bar_nav.tpl");


                        $template = str_replace("<!--ContentView-->", $fiche, $template);
                        return str_replace("<!--baniere-->", $baniere, $template);
                }


    }